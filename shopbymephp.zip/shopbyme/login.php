<?php
include("config.php");
$username=$_POST["username"];
$email=$_POST["email"];
$password=$_POST["password"];
$query="select * from shopbyme where email='$email' && password='$password'";
$result=mysqli_query($con,$query);
if(mysqli_num_rows($result)>0){
    $responce["status"]="1";
    $response["message"]="login successfull";
}
else{
    $response["status"]="0";
    $response["message"]="login failed";
}
echo json_encode($response);
?>