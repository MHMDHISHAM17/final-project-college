<?php
include("config.php");
$username=$_POST["username"];
$email=$_POST["email"];
$password=$_POST["password"];
//$gender=$_POST["gender"];


$query="insert into shopbyme(username,email,password)values('$username','$email','$password')";
$result=mysqli_query($con,$query);
if($result){
    $response["status"]="1";
    $response["message"]="Registration successfull";
}
else
{
    $response["status"]="0";
    $response["message"]="Registration failed";
}
echo json_encode($response);

?>