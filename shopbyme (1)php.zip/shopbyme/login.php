<?php
include("config.php");

$email=$_POST["username"];
$password=$_POST["password"];
$query="select * from user_registration where email='$email' && password='$password'";
$result=mysqli_query($con,$query);
if(mysqli_num_rows($result)>0){
    $response["status"]="1";
    $response["message"]="login successfull";
}
else{
    $response["status"]="0";
    $response["message"]="login failed";
}
echo json_encode($response);
?>