package com.example.shopbyme;

public interface config {
    String baseurl="http://192.168.1.34/shopbyme/";

}
