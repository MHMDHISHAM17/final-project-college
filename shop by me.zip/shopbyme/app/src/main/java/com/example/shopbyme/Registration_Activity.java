package com.example.shopbyme;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.SSLEngineResult;

public class Registration_Activity extends AppCompatActivity {
    EditText username, email, pass;
    Button login;
    RadioGroup gender;
    String username1, email1, pass1, login1, status, message, gender1;
    String url = config.baseurl + "user_registeration.php";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        username = findViewById(R.id.username);
        email = findViewById(R.id.email);
        pass = findViewById(R.id.pass);
        login = findViewById(R.id.login);
        gender = findViewById(R.id.option);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                userReg();

            }
        });


    }

    private void userReg() {
        username1 = username.getText().toString();
        email1 = email.getText().toString();
        pass1 = pass.getText().toString();
        if (TextUtils.isEmpty(username1)) {
            username.setError("Required");
            username.requestFocus();
            return;
        } else if (TextUtils.isEmpty(email1)) {
            email.setError("Required");
            email.requestFocus();
            return;
        } else if (TextUtils.isEmpty(pass1)) {
            pass.setError("Required");
            pass.requestFocus();
            return;
        }


        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONObject c = new JSONObject(response);
                            status = c.getString("status");
                            message = c.getString("message");
                            if (status.equals("0")) {
                                Toast.makeText(Registration_Activity.this, "Registration failed", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(Registration_Activity.this, "Registration successfully", Toast.LENGTH_SHORT).show();
                                Intent i = new Intent(Registration_Activity.this, MainActivity.class);
                                startActivity(i);
                                finish();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }


                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Registration_Activity.this, String.valueOf(error), Toast.LENGTH_SHORT).show();


            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("username", username1);
                params.put("email", email1);
                params.put("password", pass1);
               // params.put("gender", gender1);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }
   }

